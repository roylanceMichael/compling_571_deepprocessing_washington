#! /bin/bash
# Mike Roylance - roylance@uw.edu

python2.6 source/main.py $1 $2