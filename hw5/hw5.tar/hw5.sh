#! /bin/bash
# Mike Roylance - roylance@uw.edu

python2.6 source/main.py $1 $2 > $3
python2.6 source/main.py $1 $2 > sentences.semantics.txt